import java.util.Scanner;

class String3
{
    public static void main(String []args)
    {
        String str;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the string:");
        str=sc.nextLine();
         charSingleOccurrence(str);
    }

           
           
           public static void charSingleOccurrence(String str){
        int i=0;
        int j=0;
        char arr[]=new char[50];
        while (i<str.length()-1) {            
            if(str.charAt(i)!=str.charAt(i+1)){
                arr[j]=str.charAt(i);
                i++;
                j++;
            }else{
                i++;
            }
        }
        arr[j]=str.charAt(str.length()-1);
        for(char c:arr){
            System.out.print(c);
        }
    }
}