import java.util.Scanner;

class String4
{
 public static void main(String []args)
 {
     String str;
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the string:");
	str=sc.nextLine();

	char [] charArr=str.toCharArray();

	for(int i=0;i<charArr.length;i++)
	{
	   int count=0;
		for(int j=0;j<charArr.length;j++)
		{
			if(charArr[i]==charArr[j])
			{
				count++;
			}
			else if(charArr[i]!=charArr[j])
			{
				System.out.println("not found");
			}

               }
		if(count==1)
		{
			System.out.println(charArr[i]);
			break;
		}
	}
   }
}