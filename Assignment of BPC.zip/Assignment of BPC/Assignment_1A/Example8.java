public class Example8{
 public static void main(String [] args){

System.out.println("    J    a   v     v  a ");
System.out.println("    J   a a   v   v  a a");
System.out.println("J   J  aaaaa   V V  aaaaa");
System.out.println("  JJ  a     a   V  a     a");
}
}