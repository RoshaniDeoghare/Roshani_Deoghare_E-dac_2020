public class Example19{

public static void main(String args[]){

System.out.println(Integer.toBinaryString(5));

}}
