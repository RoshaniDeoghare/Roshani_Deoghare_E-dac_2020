public class Example5
{
  static int x = 25;
  static int y = 5;
 public static void main(String[] args)
  {
   System.out.println(x*y);
   }
}