public class Example2{

public static void main(String [] args){
int x = 74;
int y = 36;
int sum = x + y;
System.out.println("sum:"+ sum);
}
}