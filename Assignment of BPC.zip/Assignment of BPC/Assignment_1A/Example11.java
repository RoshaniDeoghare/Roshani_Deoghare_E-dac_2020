public class Example11{

public static void main(String [] args){
double R = 7.5;
double perimeter = 2 * Math.PI * R;
double area = Math.PI * R * R;

System.out.println("Perimeter is:" + perimeter);
System.out.println("Area is: "+ area);
}
}