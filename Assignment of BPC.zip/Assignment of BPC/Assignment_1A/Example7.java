public class Example7 {

 public static void main(String[] args) {
  int n = 8;
  System.out.println("Input the Number: " +n);
  
  for (int i = 1; i <= 10; i++) {
   System.out.println(n + "*" + i + " = " + (n * i));
  }
 }
}