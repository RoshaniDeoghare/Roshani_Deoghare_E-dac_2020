public class Example12{

public static void main(String [] args){
 int x = 15, y = 20, z = 25;
 int avg = (x + y + z)/3;

System.out.println("Average is:" + avg);
}
}