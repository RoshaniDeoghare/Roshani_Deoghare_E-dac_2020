
public class Example6{

public static void main(String[] args) {
   
  int num1 = 125;
  System.out.print("Input first number: " +num1);
  
  int num2 = 24;
  System.out.print("Input second number: " +num2);
   
 
  System.out.println(num1 + " + " + num2 + " = " + 
  (num1 + num2));
   
  System.out.println(num1 + " - " + num2 + " = " + 
  (num1 - num2));
   
  System.out.println(num1 + " x " + num2 + " = " + 
  (num1 * num2));
   
  System.out.println(num1 + " / " + num2 + " = " + 
  (num1 / num2));
 
  System.out.println(num1 + " mod " + num2 + " = " + 
  (num1 % num2));
 }
 
}
