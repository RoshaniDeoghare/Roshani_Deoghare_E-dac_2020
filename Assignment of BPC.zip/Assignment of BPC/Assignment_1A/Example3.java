public class Example3
{
  static int x = 50;
  static int y = 3;
 public static void main(String[] args)
  {
   System.out.println(x/y);
   }
}