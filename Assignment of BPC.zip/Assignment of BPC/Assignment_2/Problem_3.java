import java.util.Scanner;

class Problem_3
{
 public static void main(String args[])
 {

  Scanner input = new Scanner(System.in);

  System.out.println("Enter the number from 0-9:");
  int row = input.nextInt();
  int space = row;
  
  for(int i=1;i<=row;i++)
   {
    for(int j=1;j<=space;j++)
    {
     System.out.print(" ");
     }
    space--;

     for(int k=1;k<=i;k++)
     {
     System.out.print("* ");
     }
     System.out.println();
    }
  }
}

