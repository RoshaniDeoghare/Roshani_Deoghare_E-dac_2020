class PyramidPattern6
{
 public static void main(String args [])
 {
 // row
    for(int i=1;i<=9;i++)
    { 

// spaces
     for(int j=9;j>=i;j--)
      {
       System.out.print("  ");
      }

// print *
     for(int k=1;k<=i;k++)
      {
       System.out.print(i+" ");
      }
// Pattern2

     for(int m=8;m<=i;m++)
      {
       System.out.print(i+" ");
      }
      System.out.println();
     }
 }
}