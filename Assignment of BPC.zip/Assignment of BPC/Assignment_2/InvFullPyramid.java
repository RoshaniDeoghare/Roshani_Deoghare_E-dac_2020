class InvFullPyramid
{
 public static void main(String args[])
 {

  int row = 6;
  int c = 6;
  int space = 1;
  
   for(int i=1;i<=row;i++)
    {
      for(int j=1;j<=space;j++)
       {
         System.out.print(" ");
       }
      space++;

      for(int k=1;k<=c;k++)
       {
       System.out.print("* ");
       }
      c--;

     System.out.println("");
    }
  }
}

