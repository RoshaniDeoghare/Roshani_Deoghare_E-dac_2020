import java.util.*;
class PyramidPattern5
{
 public static void main(String args [])
 {
  Scanner sc = new Scanner(System.in);
  System.out.println("Enter any number of rows from 0-9:");
  int row = sc.nextInt();
 
    for(int i=row;i>=1;i--)
    { 
     for(int j=i;j>1;j--)
      {
       System.out.print("  ");
      }


     for(int k=i;k<=row;k++)
      {
       System.out.print(k+" ");
      }
      

     for(int m=row-1;m>=i;m--)
      {
       System.out.print(m+" ");
      }
      System.out.println();
     }
 }
}