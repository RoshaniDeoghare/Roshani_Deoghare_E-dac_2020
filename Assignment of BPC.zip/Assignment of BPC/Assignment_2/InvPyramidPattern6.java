import java.util.Scanner;

class InvPyramidPattern6
{
 public static void main(String args[])
 {
  Scanner sc = new Scanner(System.in);

  System.out.println("Enter the no. of rows:");
  int row = sc.nextInt();
  int c = row;
  int space = 1;
  
   for(int i=1;i<=row;i++)
    {
      for(int j=1;j<=space;j++)
       {
         System.out.print(" ");
       }
      space++;

      for(int k=1;k<=c;k++)
       {
       System.out.print("* ");
       }
      c--;

     System.out.println("");
    }
  }
}

