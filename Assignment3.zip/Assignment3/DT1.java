class DT1
{
public static void main(String args[])
 {
  boolean b = false;
  char ch = 'R';
  byte by = 110;
  short sh = 25000;
  int i = 500;
  long l = 9999999999L;
  float f = 45.50F;
  double d = 56.30D;
  System.out.println(b);
  System.out.println(ch); 
    System.out.println(by);
    System.out.println(sh); 
    System.out.println(i);
    System.out.println(l); 
      System.out.println(f); 
      System.out.println(d);
  }
}