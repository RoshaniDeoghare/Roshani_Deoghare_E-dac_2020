/* Program for inserting elemnts in linkedlist */

package datastructure;

class Node
{
    int data;
    Node next;

	Node(int d)
	{
            data = d;
            next = null;
	}
}

class InsertLinkedList
{
       Node head;
      
       public void insert(int data)
       {
          Node newNode = new Node(data);
          
          if(head == null)
          {
              head = newNode;
          }
           else
          {
              newNode.data = data;
              newNode.next = head;
              head = newNode;
          }
       }
	
	public void PrintList()
	{
		Node n = head;
		while(n != null)
		{
			System.out.println(n.data+" ");
			n = n.next;
		}
	}

	public static void main(String args[])
	{
		InsertLinkedList l = new InsertLinkedList();
		
                l.insert(10);
                l.insert(20);
                l.insert(30);
                l.insert(40);
                l.insert(50);
                
		l.PrintList();
	}
}