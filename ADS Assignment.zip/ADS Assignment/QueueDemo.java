/* Java Program to implement basic Queue operation (Enqueue and Dequeue)*/

package datastructure;

class QueueDemo
{
    int front,rear;
    int capacity;
    int queue[];
    
    QueueDemo(int capacity)
    {
        front = rear = 0;
        this.capacity = capacity;
        queue = new int [capacity];
    }
    
    boolean isFull()
    {
        return rear == capacity;
    }
    
    boolean isEmpty()
    {
        return front == rear;
    }
    
    public void enqueueQueue(int ele)
    {
        if(isFull())
        {
            System.out.println("Queue is full");   
        }
        else
        {
            queue[rear] = ele;
            rear++;
        }
        
    } 
    
    public void dequeueQueue()
    {
        if(isEmpty())
        {
            System.out.println("Queue is empty");
        }
        else
        {
            for(int i = 0;i<rear -1;i++)
                queue [i] = queue[i+1];
        } 
        rear--;
    }
    
    public void display()
    {
        if(front == rear)
        {
            System.out.println("Queue is empty");
        }
        else
        {
            for(int i = front;i < rear;i++)
                 System.out.println(queue[i]+" ");
       
        }
    }

    public static void main(String args[])
    {
        QueueDemo q = new QueueDemo(5);
        q.enqueueQueue(20);
        q.enqueueQueue(30);
        //q.display();
        q.enqueueQueue(40);
        q.enqueueQueue(50);
        q.enqueueQueue(60);
        q.display();
        System.out.println("After Dequeue");
        q.dequeueQueue();
        q.display();
        q.enqueueQueue(70);
        q.enqueueQueue(80);
        q.display();
        
        
    }
}


   