/* Java program to implement Singly linkedlist  and its operations */

package datastructure;

class Node1
{
    int data;
    Node1 next;
    
    Node1(int data)
    {
        this.data = data;
        this.next = null;
    }
    
}

class LinkedList_1
{
    Node1 head;
    int length;
    
    public void insertBeg(int data)
    {
        Node1 newNode = new Node1(data);
      
        newNode.next = head;
        head = newNode;       
    }

    public void insertMid(int data,int pos)
    {
        Node1 newNode = new Node1(data);
        Node1 prev_node = new Node1(data);
        
        int i =1;   //position of node
        prev_node = head;
        while(prev_node.next != null)
        {
            i++;
             if(pos == i)
                 break;
             prev_node = prev_node.next;
        }
       
        newNode.next = prev_node.next;
        prev_node.next = newNode;
               
    } 
    
    public void insertEnd(int data)
    {
        Node1 newNode = new Node1(data);
       
        Node1 last = head;
        
        while (last.next != null)
            
        last = last.next; 
        last.next = newNode; 
        newNode.next = null;
    
        
    }

    public void PrintList()
	{
		Node1 n = head;
		while(n != null)
		{
			System.out.print(n.data+"->");
			n = n.next;
		}
	}  
    
    public static void main(String args[])
    {
        LinkedList_1 l1 = new LinkedList_1();
        
        l1.insertBeg(10);
        l1.insertBeg(20);
        l1.insertBeg(30);
        l1.insertBeg(50);
        //l1.PrintList();
        
        l1.insertMid(40,2);
        //l1.PrintList();
        
        l1.insertEnd(25);
        l1.insertEnd(35);
        
        l1.PrintList();
        
    }
    
    
}