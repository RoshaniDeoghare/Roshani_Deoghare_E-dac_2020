/* Java program to implement Circular Queue */


package datastructure;

class CircularQueue
{
    int front,rear;
    int capacity;
    int cirQueue []= new int[capacity];
    
    CircularQueue(int capacity)
    {
        this.capacity = capacity;
        this.front = -1;
        this.rear = -1;
        
    } 
    
    public void Enqueue(int ele)
    {
        if(((rear + 1)% capacity) == front)
        {
            System.out.println("Queue is full");
        } 
        else
        {
            if(rear == front && front == -1)
            {
                front = 0;
            }
            
            rear = (rear + 1) % capacity;
            cirQueue[rear] = ele;
        }
    } 
    
    public void Dequeue()
    {
        if(rear == front && rear == -1)
        {
            System.out.println("Queue is empty");
        } 
        else
        {
            int ele = cirQueue[front];
            cirQueue[front] = 0;
            if(rear == front)
            {
                rear = -1;
                front = -1;
            } 
            else
            {
                front = (front + 1) % capacity;
            } 
            
            System.out.println(ele+" dequeue from the queue");
        }
    } 
    
    public void Display()
    {
        if(rear == front)
        {
            System.out.println("Queue is empty");
        }
        
        for(int i = front; i < rear; i++)
        {
            System.out.println("cirQueue[i]");
        }
    } 
    
    public static void main(String args[])
    {
        int capacity = 10;
        
        CircularQueue q = new CircularQueue(capacity);
        
        q.Enqueue(10);
        q.Enqueue(20);
        q.Enqueue(30);
        q.Enqueue(40);
        q.Enqueue(50);
        
        q.Display();
        
        q.Dequeue();
        
    }
}