class Array1
{
	long [] arr = new long[100];
	int n;

	public Array1()
	{
		int n = 0;
	}

	public boolean find(long searchkey) 	//Search element in array
	{
			
		for(int j = 0; j < n;j++)
		{
			if(arr[j] == searchkey)
				break;

			if(j == n)
				return false;
				//System.out.println("Not found!!");
			else
				return true;
				//System.out.println("Element found!!!"+searchkey);
		}
	}

	public void insert(long value)
	{
		arr[n] = value;
		n++;
	}

	public boolean delete(long value)	//Search and Delete element from an array
	{
		int j;
		for( j = 0; j < n;j++)
		{
			if(arr[j] == value)
				break;
			
			if(j == n)
				return false;

			else
			for(int k = j; k= n-1; k++)
			{
				arr[k] = arr[k + 1];
				
			}
		}

		n--;
		return true;
	}

	public void display()  		//Display array elements
		
	{
		for(int j =0;j<n;j++)
		{
			System.out.print(arr[j]+" ");
		}	
	}
}


class ArrayTest1
{
	public static void main(String args[])
	{
		Array1 a1;
		a1 = new Array1();

		a1.insert(10);
		a1.insert(20);
		a1.insert(30);
		a1.insert(40);
		a1.insert(50);
		a1.display();
		System.out.println();
		
		if(a1.find(35))
			System.out.println("Not found!!");
		else
			System.out.println("Element found!!!");

		a1.delete(20);
		a1.display();
	}
}
		
	