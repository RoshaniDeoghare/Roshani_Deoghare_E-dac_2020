/* Program to check parantheses balanced or not. */

package datastructure;

class Check
{
	String s = new String();
	
	boolean isBalanced(String str)
	{
		for(int i =0;i < s.length();i++)
		{
			char ch = str.charAt(i);
			if((ch == '(') || (ch == '[') || (ch == '{'))
				{
					s.push(ch);
				}
				if(s.isEmpty())
					return false;
					
				switch(ch)
				{
					case ')':
							 if(s.peek() == '(')
							 s.pop();
							 break;
								
					case ']':
							 if(s.peek() == '[')
							 s.pop();
							 break;
							 
				    case '}':
					         if(s.peek() == '{')
							 s.pop();
							 break;
				}
		}
		return s.isEmpty();
	} 
}
class ParanthesesCheck
{
	public static void main(String args[])
	{
		Check c = new Check();
		if((c.isBalanced("[{()]") == true))
			System.out.println("Balanced");
		else
			System.out.println("Not Balanced");
	}
}	
							 
							 
							 
							 