class ArrayTest
{
	public static void main(String args[])
	{
		long [] arr = new long[100];
		int n = 0;
		int j;
		long searchkey;

		arr[0]= 10;
		arr[1]= 15;
		arr[2]= 25;
		arr[3]= 30;
		arr[4]= 40;
		arr[5]= 56;	
		arr[6]= 60;	
		arr[7]= 75;
		arr[8]= 80;
		arr[9]= 90;
		n = 10;

		//Display array elements
		for( j =0;j<n;j++)
		{
			System.out.print(arr[j]+" ");
		}

		//Search element in array
		searchkey = 66;	
		for(j = 0; j < n;j++)
		{
			if(arr[j] == searchkey)
				break;

			if(j == n)
				System.out.println("Not found!!");
			else
				System.out.println("Element found!!!");
		}

		//Search and Delete element from an array
		searchkey = 40;	
		for(j = 0; j < n;j++)
		{
			if(arr[j] == searchkey)
				break;

			for(int k = j; k = n-1; k++)
			{
				arr[k] = arr[k + 1];
				n--;
			}
		}

		//Display array elements after deleting element
		for( j =0;j<n;j++)
		{
			System.out.print(arr[j]+" ");
		}

	}
}