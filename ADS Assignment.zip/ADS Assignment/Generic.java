/* Program to implement comaparison of numbers */

package datastructure;

public class Generic
{
    public static <T extends Comparable<T>> T maximum(T x, T y, T z)
    {
        T max = x; 		//assume x is largest number
        
        if(y.compareTo(max) > 0)
            
          max = y;		// assume y is largest number
        
        if(z.compareTo(max)> 0)
            
          max = z; 		// assume z is largest number
        return max;
           
    }
    
    public static void main(String args [])
    {
        System.out.printf("The largest number is %d,%d and %d is %d \n \n", 4, 8, 9, maximum(4,8,9));
        
        System.out.printf("The largest number is %.1f,%.1f and %.1f is %.1f \n \n", 2.5, 4.5, 6.5, maximum(2.5, 4.5, 6.5));

        System.out.printf("The largest number is %f,%f and %f is %f \n \n", 12.45, 28.25, 30.54, maximum(12.45, 28.25, 30.54));
        
        
    }
    
   
} 