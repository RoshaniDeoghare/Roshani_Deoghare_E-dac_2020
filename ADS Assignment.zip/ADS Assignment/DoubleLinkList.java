/* Program for Doubly LinkedList wits its operation*/

package datastructure;

class Node2
{
	int data;
	Node2 fLink;
	Node2 bLink;

	Node2(int data)
	{
		this.data = data;
		this.bLink = this.fLink = null;
	}
}

class DoubleLinkList
{
	Node2 start;
	int length;

	DoubleLinkList()
	{
		this.start = null;
		this.length = 0;
	}

	void insertBeg(int data)
	{
		Node2 newNode = new Node2(data);
		
		if(start == null)
		{
			start = newNode;
		}
		else
		{
			start.bLink = newNode;
			newNode.fLink = start;
			start = newNode;
		}
		
		length++;
	}

	void insertEnd(int data)
	{
		Node2 newNode = new Node2(data);
               
		if(start == null)
		{
			start = newNode;
		}
		else
                {
                    Node2 n = start;	
                    while(n.fLink != null)	//for traversing list
                    {
			n = n.fLink;
                    }

		n.fLink = newNode;
		newNode.bLink = n;
                }
            length++;

        }

	
	void insertMid(int data,int pos)	//insert at specific position in middle
	{
		Node2 newNode = new Node2(data);
		
		if(pos == 1)
		{
			insertBeg(data);
		}
		else if(pos > length)
		{
			insertEnd(data);
		}
		else
		{
			int i =1;
			Node2 n = start;

			while(n.fLink != null)	//for traversing link
			{
				i++;
				if(pos == i)	//check position of node where the node is to be inserted
					break;
				n = n.fLink;
			}
			
			newNode.bLink= n;
			newNode.fLink= n.fLink;
			n.fLink.bLink = newNode;
			n.fLink = newNode;
		}

		length++;
	}

	
	void deleteBeg()
	{
		Node2 n = start;
		
		if(start == null)
		{
			System.out.println("List is empty");
		}
		else
		{
			start = n.fLink;
			start.bLink = null;
		}

		length--;
	}


	void deletePos(int pos)
	{
		if(pos < 0)
		{
			System.out.println("Position does not exist");
			return;
		}

		if(pos == 1)
		{
			deleteBeg();
		}
		else if(pos > length)
		{
			deleteEnd();
		}
		else
		{
			int i=1;
			Node2 p = start;

			while(p.fLink != null)
			{
				i++;
				if(i == pos)
					break;
				p = p.fLink;
			}
		
			
			p.fLink.fLink.bLink = p;
			p.fLink = p.fLink.fLink;
		}
		
		length--;
	}

	void deleteEnd()
	{
		if(start == null)
		{
			System.out.println("List is empty");
		}
		else
		{
			Node2 n = start;

			while(n.fLink.fLink != null)
			{
				n = n.fLink;
			}
		
			n.fLink.bLink = null;
			n.fLink = null;
			length--;
		}
	}

	void displayForward()
	{
		Node2 n = start;
		
		while(n.fLink != null)
		{
			System.out.print(n.data+" -> ");
			n = n.fLink;
		}
		System.out.println(n.data + " ");
	}

	void displayBackward()
	{
		Node2 n = start;
		
		while(n.fLink!= null)
		{
			n = n.fLink;
		}

		while(n.bLink != null)
		{
			System.out.print(n.data+" -> ");
			n = n.bLink;
		}
		
		System.out.println(n.data + " ");
	}
		

   public static void main(String args[])
   {
	DoubleLinkList d1 = new DoubleLinkList();

	d1.insertBeg(10);	
	d1.insertBeg(20);
	d1.insertBeg(30);
	d1.insertEnd(40);
	d1.insertMid(25,2);
	d1.displayForward();

	System.out.println();

	d1.deleteEnd();	
	d1.deleteEnd();

	d1.displayForward();
	System.out.println();

	d1.displayBackward();
    }
}


