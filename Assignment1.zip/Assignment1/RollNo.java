class RollNo
{ 

 public static void main(String args[])
 {

  int rollno =100;
  System.out.println("Roll No ="+rollno);
  }
}