import java.util.Scanner;

class UserName
{ 

 public static void main(String args[])
 {
  String username;
  Scanner sc =new Scanner(System.in);
  username = sc.nextLine();

  System.out.println("Welcome "+username);

  }
}