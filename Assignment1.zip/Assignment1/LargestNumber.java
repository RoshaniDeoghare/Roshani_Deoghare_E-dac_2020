import java.util.*;

class Largestnumber
{
	public static void main(String args[])
	{
		int x,y,z;
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter the numbers :");
		x = sc.nextInt();
		y = sc.nextInt();
		z = sc.nextInt();
		
		if( x > y && x > z)
		{
			System.out.println(x+ " is the largest number");
		}
        elseif( y > z && y > x )
		{
			System.out.println(y+ " is the largest number");
		}
		elseif
		{
			System.out.println(z+ " is the largest number");
		}
	}
}	