class StringArray
 {
   public static void main(String args[])
    {

     String name [] = { "Roshani", "Mrunal", "Rudrani", "Savita", "Neeta"};
    
     for(int i=0; i<name.length; i++)
      {
        System.out.println( name[i] );
      }
    }
}