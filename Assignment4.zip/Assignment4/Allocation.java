//Static Allocation of Array

int arr[10] = { 2,4,6,8,10,12,14,16,18,20 };


//Dynamic Allocation of Array

int arr[] = new int[5];